
exports.GOOGLE_API_KEY = 'AIzaSyCpgbji1klCW_v6220mRyr3eY-WIFmXOKE';

exports.GENIUS_API_KEY = 'zdTLphFCy4pAlmK1mWEIn5Sw7B1N38XUp8UDeJcUGMavINCWSF3W9VakeQI8Z202';

exports.yandex_API = '7dbe6eb877b74dc4b6e34fe6ec6da86e';

exports.news_API = '7dbe6eb877b74dc4b6e34fe6ec6da86e';

exports.giphy_API = 'CaJxgWS4z2CImmnPsbfLBuGTWLkmElVx';

exports.AME_API = '6f5f59280172426c821ece5adf83ac01877c0f7ad59946bf66a72c5addd2818907597db29d5512ba1170a9fbfee287bc68a755ae0306d137993a43a28393a040';

exports.blague_API = 'rwfcDdWYMrMfdy9WvihcQeEO1-R_s1eh7hNttZFIzPEq5EZDcH2g3WiaO0ccyVml';

